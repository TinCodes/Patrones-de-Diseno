package Decorator.exercise;

public interface Component {
    public int price = 100;
    public int getPrice();
    public abstract void operation();

}
